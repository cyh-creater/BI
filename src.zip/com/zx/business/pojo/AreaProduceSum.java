package com.zx.business.pojo;

public class AreaProduceSum {
    private Integer month;

    private Float sum;

    private Float firstIndustry;

    private Float secondIndustry;

    private Float thirdIndustry;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getSum() {
        return sum;
    }

    public void setSum(Float sum) {
        this.sum = sum;
    }

    public Float getFirstIndustry() {
        return firstIndustry;
    }

    public void setFirstIndustry(Float firstIndustry) {
        this.firstIndustry = firstIndustry;
    }

    public Float getSecondIndustry() {
        return secondIndustry;
    }

    public void setSecondIndustry(Float secondIndustry) {
        this.secondIndustry = secondIndustry;
    }

    public Float getThirdIndustry() {
        return thirdIndustry;
    }

    public void setThirdIndustry(Float thirdIndustry) {
        this.thirdIndustry = thirdIndustry;
    }
}