package com.zx.business.pojo;

public class GudingzichanTz {
    private Integer month;

    private Float gudingZctz;

    private Float firstIndustry;

    private Float secondIndustry;

    private Float thirdIndustry;

    private Float fangdichan;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getGudingZctz() {
        return gudingZctz;
    }

    public void setGudingZctz(Float gudingZctz) {
        this.gudingZctz = gudingZctz;
    }

    public Float getFirstIndustry() {
        return firstIndustry;
    }

    public void setFirstIndustry(Float firstIndustry) {
        this.firstIndustry = firstIndustry;
    }

    public Float getSecondIndustry() {
        return secondIndustry;
    }

    public void setSecondIndustry(Float secondIndustry) {
        this.secondIndustry = secondIndustry;
    }

    public Float getThirdIndustry() {
        return thirdIndustry;
    }

    public void setThirdIndustry(Float thirdIndustry) {
        this.thirdIndustry = thirdIndustry;
    }

    public Float getFangdichan() {
        return fangdichan;
    }

    public void setFangdichan(Float fangdichan) {
        this.fangdichan = fangdichan;
    }
}