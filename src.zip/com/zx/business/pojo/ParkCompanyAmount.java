package com.zx.business.pojo;

public class ParkCompanyAmount {
    private Integer month;

    private Integer publicCompany;

    private Integer groupCompany;

    private Integer shareCooperateCompany;

    private Integer lianYingCompany;

    private Integer limitedLiabilityCompany;

    private Integer shareLimitedCompany;

    private Integer privateCompany;

    private Integer hkMTCompany;

    private Integer foreignCompany;

    private Integer other;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getPublicCompany() {
        return publicCompany;
    }

    public void setPublicCompany(Integer publicCompany) {
        this.publicCompany = publicCompany;
    }

    public Integer getGroupCompany() {
        return groupCompany;
    }

    public void setGroupCompany(Integer groupCompany) {
        this.groupCompany = groupCompany;
    }

    public Integer getShareCooperateCompany() {
        return shareCooperateCompany;
    }

    public void setShareCooperateCompany(Integer shareCooperateCompany) {
        this.shareCooperateCompany = shareCooperateCompany;
    }

    public Integer getLianYingCompany() {
        return lianYingCompany;
    }

    public void setLianYingCompany(Integer lianYingCompany) {
        this.lianYingCompany = lianYingCompany;
    }

    public Integer getLimitedLiabilityCompany() {
        return limitedLiabilityCompany;
    }

    public void setLimitedLiabilityCompany(Integer limitedLiabilityCompany) {
        this.limitedLiabilityCompany = limitedLiabilityCompany;
    }

    public Integer getShareLimitedCompany() {
        return shareLimitedCompany;
    }

    public void setShareLimitedCompany(Integer shareLimitedCompany) {
        this.shareLimitedCompany = shareLimitedCompany;
    }

    public Integer getPrivateCompany() {
        return privateCompany;
    }

    public void setPrivateCompany(Integer privateCompany) {
        this.privateCompany = privateCompany;
    }

    public Integer getHkMTCompany() {
        return hkMTCompany;
    }

    public void setHkMTCompany(Integer hkMTCompany) {
        this.hkMTCompany = hkMTCompany;
    }

    public Integer getForeignCompany() {
        return foreignCompany;
    }

    public void setForeignCompany(Integer foreignCompany) {
        this.foreignCompany = foreignCompany;
    }

    public Integer getOther() {
        return other;
    }

    public void setOther(Integer other) {
        this.other = other;
    }
}