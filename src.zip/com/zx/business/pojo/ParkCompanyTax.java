package com.zx.business.pojo;

public class ParkCompanyTax {
    private Integer month;

    private Float parkTax;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getParkTax() {
        return parkTax;
    }

    public void setParkTax(Float parkTax) {
        this.parkTax = parkTax;
    }
}