package com.zx.business.pojo;

public class TotalTourismIncome {
    private Integer month;

    private Float totalTourismIncome;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getTotalTourismIncome() {
        return totalTourismIncome;
    }

    public void setTotalTourismIncome(Float totalTourismIncome) {
        this.totalTourismIncome = totalTourismIncome;
    }
}