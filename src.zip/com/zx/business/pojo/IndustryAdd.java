package com.zx.business.pojo;

public class IndustryAdd {
    private Integer month;

    private Float bigIndustryAdd;

    private Float bigZxqyAdd;

    private Float industryCpxsl;

    private Float fadianliang;

    private Float yuanquGyydl;

    private Float railHyl;

    private Float roadHyl;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getBigIndustryAdd() {
        return bigIndustryAdd;
    }

    public void setBigIndustryAdd(Float bigIndustryAdd) {
        this.bigIndustryAdd = bigIndustryAdd;
    }

    public Float getBigZxqyAdd() {
        return bigZxqyAdd;
    }

    public void setBigZxqyAdd(Float bigZxqyAdd) {
        this.bigZxqyAdd = bigZxqyAdd;
    }

    public Float getIndustryCpxsl() {
        return industryCpxsl;
    }

    public void setIndustryCpxsl(Float industryCpxsl) {
        this.industryCpxsl = industryCpxsl;
    }

    public Float getFadianliang() {
        return fadianliang;
    }

    public void setFadianliang(Float fadianliang) {
        this.fadianliang = fadianliang;
    }

    public Float getYuanquGyydl() {
        return yuanquGyydl;
    }

    public void setYuanquGyydl(Float yuanquGyydl) {
        this.yuanquGyydl = yuanquGyydl;
    }

    public Float getRailHyl() {
        return railHyl;
    }

    public void setRailHyl(Float railHyl) {
        this.railHyl = railHyl;
    }

    public Float getRoadHyl() {
        return roadHyl;
    }

    public void setRoadHyl(Float roadHyl) {
        this.roadHyl = roadHyl;
    }
}