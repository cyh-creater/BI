package com.zx.business.pojo;

public class ParkCompanyStruct {
    private Integer month;

    private Integer nongLinMYIndustry;

    private Integer caiKuangIndustry;

    private Integer produceIndustry;

    private Integer dianReRqSGIndustry;

    private Integer buildingIndustry;

    private Integer pifaLsIndustry;

    private Integer trafficHouseMailIndustry;

    private Integer hostelCateringIndustry;

    private Integer infoTranSoftItIndustry;

    private Integer bankingIndustry;

    private Integer fangdichanIndustry;

    private Integer rentBusinessIndustry;

    private Integer scienceTechnologyIndustry;

    private Integer waterEnvironmentPublicIndustry;

    private Integer neighbourRepairOtherIndustry;

    private Integer educationIndustry;

    private Integer healthSocialWork;

    private Integer cultureSportAmusementIndustry;

    private Integer publicSocialSeSocialOr;

    private Integer internationalOrganization;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getNongLinMYIndustry() {
        return nongLinMYIndustry;
    }

    public void setNongLinMYIndustry(Integer nongLinMYIndustry) {
        this.nongLinMYIndustry = nongLinMYIndustry;
    }

    public Integer getCaiKuangIndustry() {
        return caiKuangIndustry;
    }

    public void setCaiKuangIndustry(Integer caiKuangIndustry) {
        this.caiKuangIndustry = caiKuangIndustry;
    }

    public Integer getProduceIndustry() {
        return produceIndustry;
    }

    public void setProduceIndustry(Integer produceIndustry) {
        this.produceIndustry = produceIndustry;
    }

    public Integer getDianReRqSGIndustry() {
        return dianReRqSGIndustry;
    }

    public void setDianReRqSGIndustry(Integer dianReRqSGIndustry) {
        this.dianReRqSGIndustry = dianReRqSGIndustry;
    }

    public Integer getBuildingIndustry() {
        return buildingIndustry;
    }

    public void setBuildingIndustry(Integer buildingIndustry) {
        this.buildingIndustry = buildingIndustry;
    }

    public Integer getPifaLsIndustry() {
        return pifaLsIndustry;
    }

    public void setPifaLsIndustry(Integer pifaLsIndustry) {
        this.pifaLsIndustry = pifaLsIndustry;
    }

    public Integer getTrafficHouseMailIndustry() {
        return trafficHouseMailIndustry;
    }

    public void setTrafficHouseMailIndustry(Integer trafficHouseMailIndustry) {
        this.trafficHouseMailIndustry = trafficHouseMailIndustry;
    }

    public Integer getHostelCateringIndustry() {
        return hostelCateringIndustry;
    }

    public void setHostelCateringIndustry(Integer hostelCateringIndustry) {
        this.hostelCateringIndustry = hostelCateringIndustry;
    }

    public Integer getInfoTranSoftItIndustry() {
        return infoTranSoftItIndustry;
    }

    public void setInfoTranSoftItIndustry(Integer infoTranSoftItIndustry) {
        this.infoTranSoftItIndustry = infoTranSoftItIndustry;
    }

    public Integer getBankingIndustry() {
        return bankingIndustry;
    }

    public void setBankingIndustry(Integer bankingIndustry) {
        this.bankingIndustry = bankingIndustry;
    }

    public Integer getFangdichanIndustry() {
        return fangdichanIndustry;
    }

    public void setFangdichanIndustry(Integer fangdichanIndustry) {
        this.fangdichanIndustry = fangdichanIndustry;
    }

    public Integer getRentBusinessIndustry() {
        return rentBusinessIndustry;
    }

    public void setRentBusinessIndustry(Integer rentBusinessIndustry) {
        this.rentBusinessIndustry = rentBusinessIndustry;
    }

    public Integer getScienceTechnologyIndustry() {
        return scienceTechnologyIndustry;
    }

    public void setScienceTechnologyIndustry(Integer scienceTechnologyIndustry) {
        this.scienceTechnologyIndustry = scienceTechnologyIndustry;
    }

    public Integer getWaterEnvironmentPublicIndustry() {
        return waterEnvironmentPublicIndustry;
    }

    public void setWaterEnvironmentPublicIndustry(Integer waterEnvironmentPublicIndustry) {
        this.waterEnvironmentPublicIndustry = waterEnvironmentPublicIndustry;
    }

    public Integer getNeighbourRepairOtherIndustry() {
        return neighbourRepairOtherIndustry;
    }

    public void setNeighbourRepairOtherIndustry(Integer neighbourRepairOtherIndustry) {
        this.neighbourRepairOtherIndustry = neighbourRepairOtherIndustry;
    }

    public Integer getEducationIndustry() {
        return educationIndustry;
    }

    public void setEducationIndustry(Integer educationIndustry) {
        this.educationIndustry = educationIndustry;
    }

    public Integer getHealthSocialWork() {
        return healthSocialWork;
    }

    public void setHealthSocialWork(Integer healthSocialWork) {
        this.healthSocialWork = healthSocialWork;
    }

    public Integer getCultureSportAmusementIndustry() {
        return cultureSportAmusementIndustry;
    }

    public void setCultureSportAmusementIndustry(Integer cultureSportAmusementIndustry) {
        this.cultureSportAmusementIndustry = cultureSportAmusementIndustry;
    }

    public Integer getPublicSocialSeSocialOr() {
        return publicSocialSeSocialOr;
    }

    public void setPublicSocialSeSocialOr(Integer publicSocialSeSocialOr) {
        this.publicSocialSeSocialOr = publicSocialSeSocialOr;
    }

    public Integer getInternationalOrganization() {
        return internationalOrganization;
    }

    public void setInternationalOrganization(Integer internationalOrganization) {
        this.internationalOrganization = internationalOrganization;
    }
}