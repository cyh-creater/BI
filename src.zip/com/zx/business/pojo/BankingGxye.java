package com.zx.business.pojo;

public class BankingGxye {
    private Integer month;

    private Float bankingCkye;

    private Float bankingDkye;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getBankingCkye() {
        return bankingCkye;
    }

    public void setBankingCkye(Float bankingCkye) {
        this.bankingCkye = bankingCkye;
    }

    public Float getBankingDkye() {
        return bankingDkye;
    }

    public void setBankingDkye(Float bankingDkye) {
        this.bankingDkye = bankingDkye;
    }
}