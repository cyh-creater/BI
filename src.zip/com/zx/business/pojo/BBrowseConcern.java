package com.zx.business.pojo;

public class BBrowseConcern {
    private Integer id;

    private Integer bClose;

    private Integer bReleaseInfo;

    private Integer bVisit;

    private Integer bAccVisit;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getbClose() {
        return bClose;
    }

    public void setbClose(Integer bClose) {
        this.bClose = bClose;
    }

    public Integer getbReleaseInfo() {
        return bReleaseInfo;
    }

    public void setbReleaseInfo(Integer bReleaseInfo) {
        this.bReleaseInfo = bReleaseInfo;
    }

    public Integer getbVisit() {
        return bVisit;
    }

    public void setbVisit(Integer bVisit) {
        this.bVisit = bVisit;
    }

    public Integer getbAccVisit() {
        return bAccVisit;
    }

    public void setbAccVisit(Integer bAccVisit) {
        this.bAccVisit = bAccVisit;
    }
}