package com.zx.business.pojo;

public class IndustryCcPriceZs {
    private Integer month;

    private Float industryCcPriceZs;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getIndustryCcPriceZs() {
        return industryCcPriceZs;
    }

    public void setIndustryCcPriceZs(Float industryCcPriceZs) {
        this.industryCcPriceZs = industryCcPriceZs;
    }
}