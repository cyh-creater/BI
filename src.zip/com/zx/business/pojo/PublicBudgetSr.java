package com.zx.business.pojo;

public class PublicBudgetSr {
    private Integer month;

    private Float publicBudgetSr;

    private Float publicBudgetZc;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getPublicBudgetSr() {
        return publicBudgetSr;
    }

    public void setPublicBudgetSr(Float publicBudgetSr) {
        this.publicBudgetSr = publicBudgetSr;
    }

    public Float getPublicBudgetZc() {
        return publicBudgetZc;
    }

    public void setPublicBudgetZc(Float publicBudgetZc) {
        this.publicBudgetZc = publicBudgetZc;
    }
}