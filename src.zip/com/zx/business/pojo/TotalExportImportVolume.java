package com.zx.business.pojo;

public class TotalExportImportVolume {
    private Integer month;

    private Float totalExportImportVolume;

    private Float totalExportVolume;

    private Float totalImportVolume;

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Float getTotalExportImportVolume() {
        return totalExportImportVolume;
    }

    public void setTotalExportImportVolume(Float totalExportImportVolume) {
        this.totalExportImportVolume = totalExportImportVolume;
    }

    public Float getTotalExportVolume() {
        return totalExportVolume;
    }

    public void setTotalExportVolume(Float totalExportVolume) {
        this.totalExportVolume = totalExportVolume;
    }

    public Float getTotalImportVolume() {
        return totalImportVolume;
    }

    public void setTotalImportVolume(Float totalImportVolume) {
        this.totalImportVolume = totalImportVolume;
    }
}